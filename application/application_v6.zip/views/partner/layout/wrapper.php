<?php 
$this->simple_login->cek_login_partner();
// Gabungkan file layout
require_once('head.php');
require_once('menu.php');
require_once('header.php');
require_once('content.php');
require_once('footer.php');