<?php
// Ambil data dari controller
if($content) {
	$this->load->view($content);
}