<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testing extends CI_Controller {

	public function index()
	{
		$this->load->library('email');
		$this->email->from('order@nitrico.co.id', 'Nama lengkap');
		$this->email->to('andoyoandoyo@gmail.com');
		$this->email->cc('javawebmedia@gmail.com');	
		$this->email->subject('Uji Coba Email');
		$message =$this->load->view('testing/kirim',true);
		$this->email->message($message);
		$this->email->send();
		echo $this->email->print_debugger();
	}

}

/* End of file Testing.php */
/* Location: ./application/controllers/Testing.php */