<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Testing</title>
</head>
<body>
	<h1>Uji coba email</h1>
	<table>
		<thead>
			<tr>
				<th>OK</th>
				<th>OK</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>data</td>
				<td>data</td>
			</tr>
		</tbody>
	</table>
</body>
</html>