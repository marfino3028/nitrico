<?php include('banner.php'); ?>
<!-- Start main -->
<main id="main">
<?php 
include('funnel.php');
include('produk.php');
include('pemesanan.php');
?>
</main>
<!-- End #main -->