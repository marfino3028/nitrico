<div class="site-section ftco-subscribe-1 site-blocks-cover pb-4" style="background-image: url('<?php echo $this->website->banner(); ?>')">
  <div class="container">
    <div class="row align-items-end">
      <div class="col-lg-7">
        <h2 class="mb-0"><?php echo $title ?></h2>
        <p><?php echo $deskripsi ?></p>
      </div>
    </div>
  </div>
</div> 


<div class="custom-breadcrumns border-bottom">
  <div class="container">
    <a href="<?php echo base_url() ?>">Beranda</a>
    <span class="mx-3 icon-keyboard_arrow_right"></span>
    <a href="<?php echo base_url('produk') ?>">Produk</a>
    <span class="mx-3 icon-keyboard_arrow_right"></span>
    <span class="current"><?php echo $title ?></span>
  </div>
</div>

<div class="site-section">
  <div class="container">
    <div class="row">
      <div class="col-md-12 mb-4">

      </div>
    </div>
  </div>
</div>