<div class="site-section ftco-subscribe-1 site-blocks-cover pb-4" style="background-image: url('<?php echo $this->website->banner(); ?>')">
  <div class="container">
    <div class="row align-items-end">
      <div class="col-lg-7">
        <h2 class="mb-0"><?php echo $title ?></h2>
        <p><?php echo $deskripsi ?></p>
      </div>
      <div class="col-md-5">
        <div class="text-left" style="min-height: 100px; background-color: white; padding: 20px; border-radius: 10px;color: #000 !important;">
          <p style="color: #000;">
            <strong>PENDAFTARAN:</strong><br>
          <i class="fa fa-envelope"></i> <?php echo $site->email ?>
          <br><i class="fa fa-phone"></i> <?php echo $site->telepon ?>
          <br><i class="fab fa-whatsapp"></i> <a href="https://wa.me/<?php echo str_replace('+','',$site->hp) ?>?text=Saya ingin mendaftar produk <?php echo $produk->nama_produk ?>. Apakah bisa dibantu?" class="small mr-3" target="_blank" class="text-white" style="font-size: 16px; color: black;"><strong><?php echo $site->hp ?></strong></a>
        </p>
         <p style="color: #000;">
          <a href="<?php echo base_url('pendaftaran') ?>" class="btn btn-primary btn-block"><i class="fa fa-edit"></i> Pendaftaran Produk</a>
         </p>
        </div>
      </div>
    </div>
  </div>
</div> 


<div class="custom-breadcrumns border-bottom">
  <div class="container">
    <a href="<?php echo base_url() ?>">Beranda</a>
    <span class="mx-3 icon-keyboard_arrow_right"></span>
    <a href="<?php echo base_url('produk') ?>">Produk</a>
    <span class="mx-3 icon-keyboard_arrow_right"></span>
    <span class="current"><?php echo $title ?></span>
  </div>
</div>

<div class="site-section">
  <div class="container">
    <div class="row">
      <div class="col-md-4 mb-4">
        <p>
          <img src="<?php echo base_url('assets/upload/image/'.$produk->gambar) ?>" alt="<?php echo $produk->nama_produk; ?>" class="img img-thumbnail img-fluid">
        </p>
      </div>
      <div class="col-md-8 mb-4">
        <h1><?php echo $title ?> </h1>
        <p class="text-right">
          <a href="<?php echo base_url('produk/cetak/'.$produk->slug_produk) ?>" class="btn btn-warning btn-xs" target="_blank"><small><i class="fa fa-file-pdf"></i> Cetak PDF</small></a>
          <a href="<?php echo base_url('pendaftaran') ?>" class="btn btn-primary btn-xs" target="_blank"><small><i class="fa fa-edit"></i> Daftar Produk</small></a>
        </p>
        <table class="table">
          <tbody>
            <tr>
              <td width="40%">Biaya Produk Kelas (Workshop)</td>
              <td>: Rp. <?php 
              $date1    = strtotime($produk->mulai_diskon); 
              $date2    = strtotime($produk->selesai_diskon); 
              $sekarang = strtotime(date('Y-m-d'));
              if($date1 <= $sekarang && $date2 >= $sekarang) { ?>
                <strong><?php echo $this->website->angka($produk->harga_diskon); ?> <sup class="text-danger"><del>Rp. <?php echo $this->website->angka($produk->harga_jual); ?></del></sup></strong>
              <?php }else{ ?>
                <strong><?php echo $this->website->angka($produk->harga_jual); ?></strong>
              <?php } ?></td>
            </tr>
            <tr>
              <td>Biaya Produk Private</td>
              <td>: Rp. <?php 
              
              if($date1 <= $sekarang && $date2 >= $sekarang) { ?>
                <strong><?php echo $this->website->angka($produk->harga_private_diskon); ?> <sup class="text-danger"><del>Rp. <?php echo $this->website->angka($produk->harga_private); ?></del></sup></strong>
              <?php }else{ ?>
                <strong><?php echo $this->website->angka($produk->harga_private); ?></strong>
              <?php } ?>
              </td>
            </tr>
            <tr>
              <td>Durasi Produk</td>
              <td>: <?php echo $this->website->angka($produk->durasi_produk) ?> jam (<?php echo $produk->durasi_produk/2; ?> Sesi atau <?php echo round($produk->durasi_produk/3*2/4).' s/d '.round($produk->durasi_produk/2*2/4); ?> Minggu)
                <br>&nbsp; <small class="text-warning">Rata-rata 
                  Seminggu 2-3 kali pertemuan
                </small></td>
            </tr>
                  <!-- <tr>
                    <td>Jumlah siswa minimal</td>
                    <td>: <?php echo $this->website->angka($produk->jumlah_siswa_min) ?></td>
                  </tr>
                  <tr>
                    <td>Jumlah siswa maksimal</td>
                    <td>: <?php echo $this->website->angka($produk->jumlah_siswa_max) ?></td>
                  </tr> -->
                </tbody>
              </table>
              <hr>
                <h2>Deskripsi ringkas</h2>
                <?php echo $produk->deskripsi ?>
                <hr>
              <?php echo $produk->isi; if($gambar) { ?>
                <hr>
                <h2>Gambar <?php echo $produk->nama_produk ?></h2>
                <hr>
                <div class="row">
                  <?php foreach($gambar as $gambar) { ?>
                    <div class="col-md-6 text-center">
                      <p class="text-center">
                       <img src="<?php echo base_url('assets/upload/image/'.$gambar->gambar) ?>" alt="<?php echo $gambar->nama_gambar_produk; ?>" class="img img-responsive img-thumbnail">
                     </p>
                     <p class="text-center"><?php echo $gambar->nama_gambar_produk ?></p>
                   </div>

                 <?php } ?>
               </div>
             <?php } ?>
      </div>
      <div class="col-md-12">
             <hr>
             <h2 class="pb-2">Jadwal Produk <?php echo $produk->nama_produk ?>:</h2>
             <p>Untuk mendaftar produk, pilih salah satu jadwal di bawah ini, lalu klik tombol <strong>Daftar Kelas</strong> atau <strong>Daftar Private</strong></p>
              <ul>
                <li><strong>Daftar Kelas</strong>: Anda mendaftar produk dengan model belajar dalam kelas. Masing-masing produk memiliki minimal peserta/siswa.</li>
                <li><strong>Daftar Private</strong>: Anda mendaftar produk dengan model belajar private (1 tutor 1 siswa). <span class="text-danger">Produk private bisa dimulai kapan saja.</span></li>
              </ul>
             <table class="table table-bordered table-hover table-sm" id="example2">

              <thead>
                <tr class="bg-dark" style="color:white; text-transform: uppercase;">

                  <th width="15%">LOKASI</th>
                  <th width="10%">MULAI</th>
                  <th width="15%">KETERANGAN</th>
                  <th width="5%">STATUS</th>
                  <th width="20%">PENDAFTARAN</th>
                </tr>
              </thead>
              <tbody>

                <?php if($jadwal_produk) { $no=1; foreach($jadwal_produk as $jadwal_produk) { ?>
                  <tr>

                    <td><?php echo $jadwal_produk->nama_lokasi ?></td>
                    <td><?php echo date('d-m-Y',strtotime($jadwal_produk->tanggal_mulai)) ?><br>
                      <small>S/D: <?php echo date('d-m-Y',strtotime($jadwal_produk->tanggal_selesai)) ?></small>   
                    </td>
                    
                    <td><?php echo $jadwal_produk->keterangan_tanggal ?></td>
                    <td><?php echo $jadwal_produk->status_jadwal_produk ?></td>
                    <td>
                      <a href="<?php echo base_url('pendaftaran') ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i>Daftar Produk</a>
                    </td>
                  </tr>
                  <?php $no++; }}else{ ?>
                    <tr>
                      <td colspan="6">
                        Saat ini belum ada jadwal. Hubungi (via Whatsapp/Telepon) Customer Service kami untuk keterangan lebih detail.
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
              
              <p>
               <a href="<?php echo base_url('jadwal') ?>" class="btn btn-light btn-block btn-lg">
                <i class="fa fa-calendar-check"></i> Lihat Jadwal Produk Lainnya</a>
              </p>
            </div>

            <div class="col-md-12">
              <hr>
              <div class="row mb-2 justify-content-center text-center">
                <div class="col-lg-8 mb-2">
                  <h2 class="section-title-underline mb-2">
                    <span>Produk lain yang ada di <?php echo $site->namaweb ?></span>
                  </h2>
                  <p><?php echo $site->deskripsi ?></p>
                </div>
              </div>
              <div class="owl-slide-3 owl-carousel">
          <?php 
          foreach($kategori_produk as $kategori_produk) { 
            $id_kategori_produk = $kategori_produk->id_kategori_produk;
            $produk_lain   = $this->produk_model->kategori_all($id_kategori_produk);
            foreach($produk_lain as $produk_lain) { 
          ?>
            <div class="course-1-item">
              <figure class="thumnail">
                <a href="<?php echo base_url('produk/detail/'.$produk_lain->slug_produk) ?>"><img src="<?php echo base_url('assets/upload/image/thumbs/'.$produk_lain->gambar) ?>" alt="<?php  echo $produk_lain->nama_produk ?>" class="img-fluid"></a>
                <div class="price">
                  Rp. 
                  <?php $date1    = strtotime($produk_lain->mulai_diskon); 
                  $date2    = strtotime($produk_lain->selesai_diskon); 
                  $sekarang = strtotime(date('Y-m-d')); 
                  if($date1 <= $sekarang && $date2 >= $sekarang) {
                  ?>
                    <strong><?php echo $this->website->angka($produk_lain->harga_diskon); ?> <sup class="text-danger"><del>Rp. <?php echo $this->website->angka($produk_lain->harga_jual); ?></del></sup></strong>
                  <?php }else{ ?>
                    <strong><?php echo $this->website->angka($produk_lain->harga_jual); ?></strong>
                  <?php } ?>
                </div>
                <div class="category"><h3><?php  echo $produk_lain->nama_produk ?></h3></div>  
              </figure>
              <div class="course-1-content pb-1">
                <h2><a href="<?php echo base_url('produk/detail/'.$produk_lain->slug_produk) ?>"><?php  echo $produk_lain->nama_produk ?></a></h2>
                <div class="rating text-center mb-1">
                  <span class="icon-star2 text-warning"></span>
                  <span class="icon-star2 text-warning"></span>
                  <span class="icon-star2 text-warning"></span>
                  <span class="icon-star2 text-warning"></span>
                  <span class="icon-star2 text-warning"></span>
                </div>
                <p class="desc mb-2"><?php echo $produk_lain->keywords ?></p>
                <p><a href="<?php echo base_url('produk/detail/'.$produk_lain->slug_produk) ?>" class="btn btn-primary rounded-0 px-4">Daftar &amp; Lihat Detail</a></p>
              </div>
            </div>
          <?php } } ?>
        </div>

            </div>
          </div>
        </div>
      </div>
    </div>

