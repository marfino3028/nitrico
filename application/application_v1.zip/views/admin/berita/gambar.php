<div class="modal fade" id="gambar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Copy link gambar</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">

<iframe src="<?php echo base_url('admin/galeri/listing') ?>" height="500" scrolling="yes" frameBorder="0" style="width: 100%;">
  <p>Your browser does not support iframes.</p>
</iframe>

      

      </div>
    </div>
  </div>
</div>
