<div class="row">
  <div class="col-12">
    <!-- Custom Tabs -->
    <div class="card">
      <div class="card-header d-flex p-0">
        <h3 class="card-title p-3"><strong><?php echo strtoupper($title) ?></strong></h3>
        <ul class="nav nav-pills ml-auto p-2">
          <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">DETAIL CLIENT</a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/client/cetak/'.$client->id_client) ?>" target="_blank"><strong><i class="fa fa-print"></i> CETAK</strong></a></li>
        </ul>
      </div><!-- /.card-header -->
      <div class="card-body">
        <div class="tab-content">
          <div class="tab-pane active" id="tab_1">
           <?php include('detail_client.php') ?>
          </div>
          <!-- /.tab-pane -->
        </div>
        <!-- /.tab-content -->
      </div><!-- /.card-body -->
    </div>
    <!-- ./card -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->