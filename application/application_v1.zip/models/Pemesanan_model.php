<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemesanan_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing data
	public function listing() {
		$this->db->select('pemesanan.*, 
						produk.nama_produk, 
						client.nama_client,
						users.nama');
		$this->db->from('pemesanan');
		// Join dg 2 tabel
		$this->db->join('produk','produk.id_produk = pemesanan.id_produk','LEFT');
		$this->db->join('client','client.id_client = pemesanan.id_client','LEFT');
		$this->db->join('users','users.id_user = pemesanan.id_user','LEFT');
		// End join
		$this->db->order_by('id_pemesanan','DESC');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail data
	public function detail($id_pemesanan) {
		$this->db->select('pemesanan.*, 
						produk.nama_produk, 
						client.nama_client,
						users.nama');
		$this->db->from('pemesanan');
		// Join dg 2 tabel
		$this->db->join('produk','produk.id_produk = pemesanan.id_produk','LEFT');
		$this->db->join('client','client.id_client = pemesanan.id_client','LEFT');
		$this->db->join('users','users.id_user = pemesanan.id_user','LEFT');
		// End join
		$this->db->where('pemesanan.id_pemesanan',$id_pemesanan);
		$this->db->order_by('id_pemesanan','DESC');
		$query = $this->db->get();
		return $query->row();
	}

	// Tambah
	public function tambah($data) {
		$this->db->insert('pemesanan',$data);
	}

	// Edit
	public function edit($data) {
		$this->db->where('id_pemesanan',$data['id_pemesanan']);
		$this->db->update('pemesanan',$data);
	}

	// Edit
	public function edit2($data2) {
		$this->db->where('id_pemesanan',$data2['id_pemesanan']);
		$this->db->update('pemesanan',$data2);
	}

	// Delete
	public function delete($data) {
		$this->db->where('id_pemesanan',$data['id_pemesanan']);
		$this->db->delete('pemesanan',$data);
	}
}

/* End of file Pemesanan_model.php */
/* Location: ./application/models/Pemesanan_model.php */