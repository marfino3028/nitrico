<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemesanan extends CI_Controller {

	// Load database
	public function __construct()
	{
		parent::__construct();
		$this->load->model('produk_model');
		$this->load->model('kategori_produk_model');
		$this->load->model('gambar_produk_model');
		$this->load->model('produk_model');
		$this->load->library('cart');
		$this->load->model('nav_model');
		$this->load->model('pemesanan_model');
	}

	// Formulir pemesanan
	public function index()
	{
		$site 			= $this->konfigurasi_model->listing();
		$produk 		= $this->produk_model->status_produk('Publish');

		$data = array(	'title'		=> 'Formulir Pemesanan '.$site->namaweb,
						'deskripsi'	=> 'Formulir Pemesanan '.$site->namaweb,
						'keywords'	=> 'Formulir Pemesanan '.$site->namaweb,
						'site'		=> $site,
						'produk'	=> $produk,
						'content'	=> 'pemesanan/index'
					);
		$this->load->view('layout/wrapper', $data, FALSE);
	}

}

/* End of file Pemesanan.php */
/* Location: ./application/controllers/Pemesanan.php */