<?php
$site         = $this->konfigurasi_model->listing();
$nav_funnel   = $this->nav_model->nav_funnel();
?>

<!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="<?php echo base_url() ?>"><span>
          <img src="<?php echo $this->website->logo() ?>" alt="<?php echo $this->website->namaweb() ?>" style="min-height: 60px; width: auto;">
        </span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="<?php echo base_url() ?>"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <?php if($this->uri->segment(1) =='') { ?>
            <li class="active"><a href="#header">Beranda</a></li>
            <?php foreach($nav_funnel as $nav_funnel) { ?>
            <li><a href="#<?php echo $nav_funnel->slug_kategori_funnel ?>"><?php echo $nav_funnel->nama_kategori_funnel ?></a></li>
            <?php } ?>
            <li><a href="<?php echo base_url('testimoni') ?>">Testimoni</a></li>
            <li><a href="#produk">Produk</a></li>
            <li><a href="#contact">Pembelian</a></li>
          <?php }else{ ?>
            <li class="active"><a href="<?php echo base_url() ?>">Beranda</a></li>
            <?php foreach($nav_funnel as $nav_funnel) { ?>
            <li><a href="<?php echo base_url() ?>#<?php echo $nav_funnel->slug_kategori_funnel ?>"><?php echo $nav_funnel->nama_kategori_funnel ?></a></li>
            <?php } ?>
            <li><a href="<?php echo base_url('testimoni') ?>">Testimoni</a></li>
            <li><a href="<?php echo base_url() ?>#produk">Produk</a></li>
            <li><a href="<?php echo base_url() ?>#contact">Pembelian</a></li>
          <?php } ?>
            <li><a href="<?php echo base_url('pemesanan') ?>" class="orange"><i class="fa fa-shopping-cart"></i></a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->